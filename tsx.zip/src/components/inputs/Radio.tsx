import React from 'react';

interface CustomRadioProps {
  // Define any props, if needed
}

const CustomRadio: React.FC<CustomRadioProps> = () => {
  return (
    <input className='radio-button' type='radio' />
  );
};

export default CustomRadio;
